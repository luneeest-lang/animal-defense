// hp: 체력, speed: 칸/초, reward: 처치 골드, leak: 끝까지 갔을 때 줄어드는 생명
// directMult: 직접 피해 배율(독은 영향 없음), splitInto: 죽을 때 생기는 적
export const ENEMIES = {
  soldier: { hp: 40, speed: 1.0, reward: 5, leak: 1 },
  runner: { hp: 25, speed: 2.0, reward: 6, leak: 1 },
  tank: { hp: 160, speed: 0.6, reward: 12, leak: 1 },
  shield: { hp: 80, speed: 0.9, reward: 9, leak: 1, directMult: 0.5 },
  splitter: { hp: 60, speed: 1.0, reward: 8, leak: 1, splitInto: { type: 'mini', count: 2 } },
  mini: { hp: 20, speed: 1.4, reward: 2, leak: 1 },
  // 박쥐: 날아다녀서 코끼리·뱀(땅 공격, towers.js의 groundOnly)과 불사조 불길에 맞지 않는다
  bat: { hp: 30, speed: 1.6, reward: 6, leak: 1, air: true },
  // 치유사: every초마다 radius칸 안의 다른 몬스터(보스 제외)를 최대 체력의 pct만큼 회복시킨다
  healer: { hp: 70, speed: 0.85, reward: 9, leak: 1, heal: { every: 3, radius: 1.5, pct: 0.1 } },
  // 황금 몬스터: 판마다 무작위 웨이브에 가끔 나온다. 아주 빠르고, 잡으면 골드를 크게 주며(core/missions.js의 goldenReward), 놓쳐도 생명은 그대로다
  golden: { name: '황금 몬스터', golden: true, hp: 100, speed: 2.6, reward: 0, leak: 0 },
  // 보스: 5웨이브마다 다른 보스가 1마리 나온다 (boss는 첫 보스 붉은 악마)
  // skill: 중급·고급에서 쓰는 고유 능력 설명
  boss: { name: '붉은 악마', skill: '분노 — 체력이 절반 아래면 1.5배 빨라진다', boss: true, hp: 1500, speed: 0.5, reward: 200, leak: 5 },
  slimeKing: { name: '슬라임 왕', skill: '분열 — 체력 75·50·25%마다 슬라임 2마리', boss: true, hp: 1600, speed: 0.5, reward: 200, leak: 5 },
  lich: { name: '리치 왕', skill: '부하 소환 — 5초마다 해골 방패병', boss: true, hp: 1400, speed: 0.55, reward: 200, leak: 5 },
  lavaGolem: { name: '용암 거인', skill: '단단함 — 받는 피해 30% 감소', boss: true, hp: 2000, speed: 0.4, reward: 200, leak: 5 },
  shadowWolf: { name: '그림자 늑대', skill: '질주 — 6초마다 1.5초 동안 3배 빠르다', boss: true, hp: 1200, speed: 0.7, reward: 200, leak: 5 },
  dragon: { name: '흑룡', skill: '포효 — 8초마다 주변 동물을 2초 기절', boss: true, hp: 3500, speed: 0.45, reward: 300, leak: 5 },
};
