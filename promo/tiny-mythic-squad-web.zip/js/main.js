import { MAPS } from './data/maps.js';
import {
  createGame, summonTower, canMerge, mergeTowers, snapMergeTarget, sellTower, callNextWave, step, upgradeAnimal, chooseCard,
} from './core/game.js';
import { craftMythic } from './core/mythics.js';
import { snapshotGame, restoreGame, isBetweenWaves } from './core/snapshot.js';
import { resultStats } from './core/stats.js';
import { clearRewards, addCards, dexLevels, mapIndexOf } from './core/dex.js';
import { evaluate as evaluateAchievements } from './core/achievements.js';
import {
  loadSave, writeSave, recordResult, starsFor, loadRun, writeRun, clearRun,
} from './storage.js';
import { createSound, loadSoundSettings, saveSoundSettings } from './ui/sound.js';
import { createRenderer } from './ui/render.js';
import { attachInput } from './ui/input.js';
import { createHud } from './ui/hud.js';
import { LANG_KEY, pickLang, setLang, lang, t, applyStatic } from './i18n.js';
import { setRich } from './ui/icons.js';
import { exportCode, importCode, mergeSaves } from './savecode.js';
import { createTutorial, advance as advanceTutorial, next as nextTutorial, blocking as tutorialBlocks, shouldStart as tutorialStarts, TUTORIAL_KEY } from './ui/tutorial.js';
import { createTutorialView } from './ui/tutorialView.js';
import { mapToScreen } from './ui/input.js';
import { newEnemies, loadSeen, saveSeen } from './ui/enemyIntro.js';

const MAX_FRAME_DT = 0.25;
const SPEEDS = [1, 2];
// 게임 전체 진행 속도. 1x 버튼일 때도 실제 시간보다 30% 빠르게 흐른다(적 이동·공격·웨이브 사이 대기 모두).
// 규칙(core)은 게임 시간 기준이라 밸런스는 그대로다
const GAME_SPEED = 1.3;

function openStore() {
  try {
    const s = window.localStorage;
    s.getItem('td-probe');
    return s;
  } catch {
    const fail = () => { throw new Error('storage unavailable'); };
    return { getItem: fail, setItem: fail, removeItem: fail };
  }
}

const store = openStore();

// 언어: 저장한 선택이 먼저, 없으면 휴대폰(브라우저) 언어가 한국어일 때만 한국어. 화면을 만들기 전에 정한다
function readLang() {
  try { return store.getItem(LANG_KEY); } catch { return null; }
}
setLang(pickLang(readLang(), navigator.languages ?? [navigator.language]));
document.documentElement.lang = lang();
document.title = t('title');
document.querySelector('meta[name="description"]')?.setAttribute('content', t('meta.desc'));
applyStatic(document, setRich);
// 보스 경고 글꼴을 미리 불러 둔다 (index.html의 preload와 함께, 첫 경고 때 글꼴이 바뀌어 보이지 않게)
document.fonts?.load('40px Creepster').catch(() => {});
// 언어 버튼: 선택을 저장하고 새로 불러온다(패널·조합표 같은 글자를 처음부터 다시 만든다)
document.getElementById('btn-lang').addEventListener('click', () => {
  try {
    store.setItem(LANG_KEY, lang() === 'ko' ? 'en' : 'ko');
    window.location.reload();
  } catch { /* 저장이 안 되는 브라우저에서는 언어를 바꿀 수 없다 */ }
});

let save = loadSave(store);
// 이어할 게임(웨이브 사이에 자동 저장). 되살릴 수 없는 저장은 버린다
const savedRun = loadRun(store);
let run = savedRun && restoreGame(savedRun, { dex: dexLevels(save.collection) }) ? savedRun : null;
if (!run) clearRun(store);

let game = null;
let mapId = null;
let selectedTower = null;
// { towerId, x, y, map } 끌고 있는 타워, 포인터 위치(캔버스 CSS 픽셀), 맵 좌표(칸 단위)
let drag = null;
// mythicOpen: 신화 조합표가 열려 있는지 (열려 있는 동안 게임이 멈춘다)
// music, sfx: 배경음·효과음을 켰는지 (따로 켜고 끈다)
const ui = { paused: false, speed: 1, mythicOpen: false, ...loadSoundSettings(store) };
const sound = createSound();
sound.setSettings(ui);
let lastBossWarning = 0;
// 이미 소리·저장을 처리한 이벤트 목록. 카드를 고르는 동안처럼 게임이 멈추면 step이 이벤트를 비우지 않으므로
// 같은 목록을 다시 처리하지 않게 기억해 둔다 (예전에는 마지막 처치 소리가 계속 반복됐다)
let handledEvents = null;
// 새 몬스터 안내: 이미 본 몬스터, 안내할 차례를 기다리는 몬스터, 지금 카드가 닫힐 시각
const seenEnemies = loadSeen(store);
let introQueue = [];
// 지금 카드가 닫힐 시각 (카드가 없으면 null, 누르면 0이 되어 다음 프레임에 닫히거나 다음 카드로 넘어간다)
let introUntil = null;
const ENEMY_INTRO_MS = 5000;
let lastIntroWave = 0;
// 첫 판 튜토리얼 (끝나거나 건너뛰면 null)
let tutorial = null;
// 튜토리얼이 짚을 곳: 버튼은 화면 사각형, 합성은 두 동물 사이를 오가는 손가락
function drawTutorial() {
  if (!tutorial || !game) { tutorialView.show(null); return; }
  const rect = (sel) => document.querySelector(sel)?.getBoundingClientRect() ?? null;
  const target = { summon: '#btn-summon', wave: '#btn-wave', upgrade: '.upgrades', mythic: '#btn-mythic' }[tutorial.step];
  let drag = null;
  if (tutorial.step === 'merge') {
    const [a, b] = game.towers.filter((t) => game.towers.some((u) => u !== t && u.type === t.type && u.level === t.level));
    if (a && b) {
      const canvas = document.getElementById('board').getBoundingClientRect();
      const br = renderer.boardRect();
      const at = (t) => {
        const p = mapToScreen(t.col + 0.5, t.row + 0.5, br.width, br.height, game.map.cols, game.map.rows);
        return { x: canvas.left + br.x + p.x, y: canvas.top + br.y + p.y };
      };
      drag = { from: at(a), to: at(b) };
    }
  }
  tutorialView.show(tutorial, target ? rect(target) : null, drag);
}
function endTutorial() {
  tutorial = null;
  try { store.setItem(TUTORIAL_KEY, 'done'); } catch { /* 저장이 안 되면 이번 판만 끝낸다 */ }
}
let autoPaused = false;
let finished = false;
let lastTs = 0;

const renderer = createRenderer(document.getElementById('board'));
const tutorialView = createTutorialView(document, {
  onSkip: () => { endTutorial(); tutorialView.show(null); },
  onNext: () => { if (tutorial) { nextTutorial(tutorial); if (tutorial.step === 'done') endTutorial(); } },
});

const hud = createHud(document.getElementById('app'), {
  onSummon: summon,
  onUpgradeAnimal: (id) => {
    if (game && upgradeAnimal(game, id)) afterAction('upgrade');
  },
  onPickCard: (id) => {
    // 카드 고르는 동안과 고를 때는 효과음을 내지 않는다 (저장만 한다)
    if (game && chooseCard(game, id)) afterAction(null);
  },
  onOpenMythic: () => { if (game && game.status === 'running') { ui.mythicOpen = true; selectTower(null); } },
  onCloseMythic: () => { ui.mythicOpen = false; },
  onCraft: (id) => {
    if (!game) return;
    // 조합표가 열린 동안은 게임이 멈춰 있어 이벤트로는 연출이 안 나오므로 직접 부른다
    const tower = craftMythic(game, id);
    if (tower) {
      ui.mythicOpen = false;
      renderer.celebrate('mythic', tower);
      afterAction('mythic');
    }
  },
  onCallWave: () => { if (game) callNextWave(game); },
  onSpeed: () => { ui.speed = SPEEDS[(SPEEDS.indexOf(ui.speed) + 1) % SPEEDS.length]; },
  onPause: togglePause,
  onMenu: goMenu,
  onSell: () => {
    if (game && selectedTower && sellTower(game, selectedTower.id)) afterAction('sell');
    selectTower(null);
  },
  onCloseInfo: () => selectTower(null),
  onRetry: () => startMap(mapId, !!game?.endless),
  onStartMap: (id) => {
    // 이어할 게임이 있으면 지워도 되는지 한 번 묻는다
    if (run && !window.confirm(t('menu.confirmNew'))) return;
    startMap(id);
  },
  onStartEndless: (id) => {
    if (run && !window.confirm(t('menu.confirmNew'))) return;
    startMap(id, true);
  },
  onContinue: continueRun,
  onSound: () => toggleSound('sfx'),
  onMusic: () => toggleSound('music'),
});

function toggleSound(key) {
  ui[key] = !ui[key];
  sound.setSettings(ui);
  saveSoundSettings(store, ui);
  sound.unlock();
}

// 소환·합성·강화 같은 행동 뒤: 효과음을 내고, 웨이브 사이라면 바로 저장한다
function afterAction(soundName) {
  if (soundName) sound.play(soundName);
  autosave();
}

function autosave() {
  if (!game || !isBetweenWaves(game)) return;
  if (game.waveNumber === 0 && game.towers.length === 0) return; // 아무것도 안 한 새 게임은 저장하지 않는다
  run = snapshotGame(game);
  writeRun(store, run);
}

function menuRunInfo() {
  if (!run) return null;
  const map = MAPS.find((m) => m.id === run.mapId);
  return map ? { mapId: map.id, wave: run.waveNumber, endless: !!run.endless } : null;
}

function summon() {
  const tower = game && summonTower(game);
  if (tower && tutorial) advanceTutorial(tutorial, game, tower);
  if (tower) {
    renderer.celebrate('summon', tower);
    afterAction('summon');
  }
}

function selectTower(tower) {
  selectedTower = tower;
  hud.showTowerInfo(tower);
}

function togglePause() {
  if (!game || game.status !== 'running') return;
  ui.paused = !ui.paused;
  autoPaused = false;
}

const towerAt = (col, row) => game.towers.find((t) => t.col === col && t.row === row);

attachInput(document.getElementById('board'), {
  cols: MAPS[0].cols,
  rows: MAPS[0].rows,
  boardRect: () => renderer.boardRect(),
  onTap(col, row) {
    if (!game || game.status !== 'running') return;
    const tower = towerAt(col, row);
    selectTower(tower && tower !== selectedTower ? tower : null);
  },
  onCancel: () => selectTower(null),
  onDragStart(col, row) {
    if (!game || game.status !== 'running') return false;
    const tower = towerAt(col, row);
    if (!tower) return false;
    selectTower(null);
    drag = { towerId: tower.id, x: 0, y: 0 };
    return true;
  },
  onDragMove(x, y, map) {
    if (drag) Object.assign(drag, { x, y, map });
  },
  // 자석 합성: 놓은 칸이 조금 빗나가도 가까운 짝에 붙어 합쳐진다 (core/game.js의 snapMergeTarget)
  onDrop(cell, map) {
    if (drag && game) {
      const target = snapMergeTarget(game, drag.towerId, map);
      if (target && mergeTowers(game, drag.towerId, target.id)) {
        renderer.celebrate('merge', target);
        afterAction(target.level >= 3 ? 'awaken' : 'merge');
      }
    }
    drag = null;
  },
});

// endless: 무한 모드로 시작 (그 맵을 한 번 깨서 별이 있어야 한다)
function startMap(id, endless = false) {
  const map = MAPS.find((m) => m.id === id);
  if (!map || MAPS.indexOf(map) >= save.unlocked) return;
  if (endless && !save.records[id]?.stars) return;
  run = null;
  clearRun(store);
  enterGame(createGame(map, undefined, { endless, dex: dexLevels(save.collection) }));
  tutorial = tutorialStarts(store, id, endless) ? createTutorial() : null;
}

function continueRun() {
  const restored = run && restoreGame(run, { dex: dexLevels(save.collection) });
  if (!restored) {
    run = null;
    clearRun(store);
    hud.showMenu(save, null);
    return;
  }
  enterGame(restored);
}

function enterGame(g) {
  introQueue = [];
  introUntil = null;
  lastIntroWave = g.waveNumber;
  hud.hideEnemyIntro();
  mapId = g.map.id;
  game = g;
  lastBossWarning = 0;
  handledEvents = g.events;
  finished = false;
  ui.paused = false;
  ui.speed = 1;
  ui.mythicOpen = false;
  autoPaused = false;
  drag = null;
  selectTower(null);
  hud.showGame();
  renderer.resize();
  lastTs = performance.now();
}

// 안내 카드를 누르면 바로 닫는다 (다음 안내가 있으면 그다음으로)
document.getElementById('enemy-intro').addEventListener('pointerdown', () => { if (introUntil !== null) introUntil = 0; });

function goMenu() {
  tutorial = null;
  autosave();
  game = null;
  mapId = null;
  drag = null;
  selectTower(null);
  sound.setMusic(false);
  hud.showMenu(save, menuRunInfo());
}

function finish() {
  finished = true;
  const won = game.status === 'won';
  // 끝난 게임은 이어할 수 없다
  run = null;
  clearRun(store);
  sound.play(won ? 'win' : 'lose');
  // 패배한 웨이브는 막지 못한 것이므로 직전 웨이브까지만 기록한다
  const wave = won ? game.waveNumber : Math.max(0, game.waveNumber - 1);
  const prevBest = save.records[mapId]?.endlessBest ?? 0;
  save = recordResult(save, mapId, { wave, lives: game.lives, won, endless: game.endless });
  // 보통 판 30웨이브를 깨면 도감 카드를 받는다 (core/dex.js)
  let rewards = null;
  if (won && !game.endless) {
    const cards = clearRewards(mapIndexOf(mapId), starsFor(game.lives));
    const added = addCards(save, cards);
    save = added.save;
    rewards = { cards, levelUps: added.levelUps };
  }
  // 업적: 이번 판까지의 기록으로 새로 이룬 업적을 확인하고 도감 카드를 준다 (core/achievements.js)
  const ach = evaluateAchievements(save, { game, won, wave, endless: game.endless });
  save = ach.save;
  hud.showSaveWarning(!writeSave(store, save));
  hud.showResult({
    won, wave, lives: game.lives, starCount: won ? starsFor(game.lives) : 0,
    endless: game.endless ? { best: save.records[mapId].endlessBest, newBest: wave > prevBest } : null,
    stats: resultStats(game),
    rewards,
    achievements: ach.unlocked,
  });
}

function frame(ts) {
  const dt = Math.min(Math.max((ts - lastTs) / 1000, 0), MAX_FRAME_DT);
  lastTs = ts;
  if (game) {
    if (tutorial) {
      advanceTutorial(tutorial, game);
      if (tutorial.step === 'done') endTutorial();
    }
    if (!ui.paused && !ui.mythicOpen && !(tutorial && tutorialBlocks(tutorial, game)) && game.status === 'running') {
      // 결과 화면의 플레이 시간: 멈추거나 카드를 고르는 동안은 세지 않는 실제 시간
      if (!game.cardChoices) game.stats.playTime += dt;
      step(game, dt * ui.speed * GAME_SPEED);
    }
    if (game.events !== handledEvents) {
      handledEvents = game.events;
      sound.playEvents(game.events);
      if (game.events.some((e) => e.type === 'waveClear')) autosave();
    }
    // 보스 경고가 막 시작되면 불길한 울림
    if (game.bossWarning > 0 && lastBossWarning === 0) sound.play('bossWarning');
    lastBossWarning = game.bossWarning;
    sound.setMusic(game.status === 'running' && !ui.paused);
    // 끌고 있는 타워가 사라졌으면(판매, 게임 종료) 드래그를 끝낸다
    if (drag && !game.towers.some((t) => t.id === drag.towerId)) drag = null;
    const mergeTargets = drag
      ? new Set(game.towers.filter((t) => canMerge(game, drag.towerId, t.id)).map((t) => t.id))
      : new Set();
    renderer.draw(game, {
      selectedTowerId: selectedTower ? selectedTower.id : null,
      drag,
      mergeTargets,
      // 지금 놓으면 붙을 짝 (더 밝게 표시한다)
      snapTargetId: drag ? snapMergeTarget(game, drag.towerId, drag.map)?.id ?? null : null,
    });
    // 웨이브가 시작되면 처음 보는 몬스터를 하나씩 5초 동안 알려 준다
    if (game.waveNumber > lastIntroWave) {
      lastIntroWave = game.waveNumber;
      const fresh = newEnemies(game.waves[game.waveNumber - 1], seenEnemies);
      if (fresh.length) {
        fresh.forEach((type) => seenEnemies.add(type));
        saveSeen(store, seenEnemies);
        introQueue.push(...fresh);
      }
    }
    // 카드가 없거나 시간이 다 됐으면(누르면 바로) 다음 카드를 띄우고, 더 없으면 닫는다
    const cardDone = introUntil === null || ts >= introUntil;
    if (cardDone && introQueue.length) {
      hud.showEnemyIntro(introQueue.shift());
      introUntil = ts + ENEMY_INTRO_MS;
    } else if (cardDone && introUntil !== null) {
      hud.hideEnemyIntro();
      introUntil = null;
    }
    hud.update(game, ui, ui.mythicOpen);
    drawTutorial();
    if (game.status !== 'running') ui.mythicOpen = false;
    if (game.status !== 'running' && !finished) finish();
  }
  requestAnimationFrame(frame);
}

window.addEventListener('keydown', (e) => {
  if (!game || e.repeat) return;
  if (game.cardChoices && ['1', '2', '3'].includes(e.key)) chooseCard(game, game.cardChoices[Number(e.key) - 1]);
  else if (e.key === 's' || e.key === 'S') summon();
  else if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  else if (e.key === 'Escape') { selectTower(null); ui.mythicOpen = false; }
  else if (e.key === 'm' || e.key === 'M') ui.mythicOpen = !ui.mythicOpen && game.status === 'running';
});

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    autosave();
    if (game && game.status === 'running' && !ui.paused) {
      ui.paused = true;
      autoPaused = true;
    }
  } else {
    lastTs = performance.now();
    if (autoPaused) {
      ui.paused = false;
      autoPaused = false;
    }
  }
});

// 화면 가로 크기가 크게 바뀌면(회전, 창 크기 조절) 자동 일시정지한다.
// 모바일 주소창 때문에 세로만 바뀌는 경우는 무시한다.
let lastWidth = window.innerWidth;
window.addEventListener('resize', () => {
  renderer.resize();
  if (Math.abs(window.innerWidth - lastWidth) > 40 && game && game.status === 'running') {
    ui.paused = true;
    autoPaused = false;
  }
  lastWidth = window.innerWidth;
});
new ResizeObserver(() => renderer.resize()).observe(document.getElementById('stage'));

// 브라우저는 화면을 누르기 전에는 소리를 막으므로, 처음 누르거나 키를 칠 때 소리를 켠다
for (const type of ['pointerdown', 'keydown']) window.addEventListener(type, () => sound.unlock());

hud.showSaveWarning(!writeSave(store, save));
hud.showMenu(save, menuRunInfo());

// 기록 옮기기 창: 이 기기의 코드를 보여 주고, 다른 기기 코드를 합친다(savecode.js)
{
  const $ = (id) => document.getElementById(id);
  const box = $('transfer');
  const say = (key) => { $('transfer-msg').textContent = key ? t(key) : ''; };
  $('btn-transfer').addEventListener('click', () => {
    $('transfer-out').value = exportCode(save);
    $('transfer-in').value = '';
    say(null);
    box.hidden = false;
  });
  $('btn-close-transfer').addEventListener('click', () => { box.hidden = true; });
  box.addEventListener('click', (e) => { if (e.target === box) box.hidden = true; });
  $('btn-copy-code').addEventListener('click', async () => {
    const out = $('transfer-out');
    try {
      await navigator.clipboard.writeText(out.value);
    } catch {
      out.select();
      document.execCommand?.('copy');
    }
    say('transfer.copied');
  });
  $('btn-import-code').addEventListener('click', () => {
    const other = importCode($('transfer-in').value);
    if (!other) { say('transfer.bad'); return; }
    save = mergeSaves(save, other);
    const ok = writeSave(store, save);
    hud.showSaveWarning(!ok);
    say(ok ? 'transfer.done' : 'transfer.saveFail');
    $('transfer-out').value = exportCode(save);
    hud.showMenu(save, menuRunInfo());
  });
}
requestAnimationFrame((ts) => { lastTs = ts; requestAnimationFrame(frame); });
